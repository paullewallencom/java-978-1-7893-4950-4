public class Question3Day2
{
	public static void main(String[] args)
	{
		int counter = 100;
		while(counter >= 0)
		{
			System.out.println("counter = " + counter);
			counter = counter - 5;
		}
	}
}
